enum Type {
    case breakfast
    case lunch
    case dinner
    case snack
    case beverage
}

struct Food {
    let name: String
    let description: String
}

struct Section {
    let question: String
    let options: [Food]
    let type: Type
}

struct Data {
    static let sections: [Section] = [
        Section(question: "Some of my friends recommended these for me to choose. Uhmm... what's the best food that I can eat for breakfast?",
                options: [Food(name: "Soto Ayam Lamongan",
                               description: "A type of chicken soup with a yellowish gravy, that'll warm you from the inside out."),
                          Food(name: "Soto Daging Madura",
                               description: "A type of beef soup with a yellowish gravy, that'll give the extra energy to you."),
                          Food(name: "Nasi Pecel Madiun",
                               description: "A type of salad with rice and side dishes that you can choose, that'll improve nutrition in your body."),
                          Food(name: "Nasi Kuning",
                               description: "A type of processed rice with noodle and some side dishes, that'll feel different taste."),],
                type: .breakfast),
        
        Section(question: "Some of my friends recommended these for me to choose. Uhmm... then, what's the best food that I can eat for lunch?",
                options: [Food(name: "Lontong Balap",
                               description: "A type of food that can't be found in other countries, all ingredients are unique and only available in Indonesia."),
                          Food(name: "Rujak Cingur",
                               description: "A type of salad with cow nose, that'll give a fresh and savory taste in your sense."),
                          Food(name: "Bakso",
                               description: "A type of meatball with savory soup, the chewy texture of that'll make you addicted to eat again and again."),
                          Food(name: "Nasi Rawon",
                               description: "A type of beef soup with a black gravy, that'll make you feel nutty flavour and spicy taste when you eat.")],
                type: .lunch),
        
        Section(question: "Some of my friends recommended these for me to choose. Uhmm... then, what's the best food that I can eat for dinner?",
                options: [Food(name: "Bebek Goreng",
                               description: "A fried duck that served with fresh vegetables and chili sauce, that'll give unforgettable moment in yout life."),
                          Food(name: "Tempe Penyet",
                               description: "Tempe is a traditional Indonesian dish made from soybeans, the presentation same as fried duck, that'll the most interesting food that you eat."),
                          Food(name: "Tahu Telor",
                               description: "Tofu omelette accompanied with savoury peanut sauce, that'll fill your stomach with high protein."),
                          Food(name: "Nasi Goreng",
                               description: "A type of fried rice that usually cooked with pieces of chicken meat and vegetables, that'll make you have a lot of energy."),],
                type: .dinner),
        
        Section(question: "Some of my friends recommended these for me to choose. Uhmm... then, what's the best snack that I can eat for coffee break?",
                options: [Food(name: "Weci",
                               description: "A type of street fried food that many people like, the shape is thick round textured soft and crunchy on the outside."),
                          Food(name: "Lemper",
                               description: "A snack made from sticky rice, usually filled with shredded or minced chicken and wrapped in banana leaves, this can be hunger blocker before eating other foods."),
                          Food(name: "Klepon",
                               description: "A type of snack market that dominantly sweet, this is rice flour balls filled with brown sugar dough covered with grated coconut."),
                          Food(name: "Onde Onde",
                               description: "A type of street fried food, this is rice flour balls filled with green bean dough sprinkled with sesame seeds.")],
                type: .snack),
        
        Section(question: "Some of my friends recommended these for me to choose. Uhmm... then, what's the special beverage that I can drink?",
                options: [Food(name: "Es Campur",
                               description: "A type of Indonesian drinks which is made by mixing various ingredients that usually taste sweet or sour in a sweet syrup."),
                          Food(name: "STMJ",
                               description: "Hot drink with high protein ingredients like milks, eggs, honey, and ginger, this is usually found at night."),
                          Food(name: "Es Dawet",
                               description: "The taste of this beverage is sweet and savory, because it is made from coconut milk and liquid brown sugar."),
                          Food(name: "Es Cincau",
                               description: "A type of refreshing drink with the main ingredient of gel which is similar to jelly.")
                ],
                type: .beverage)
    ] 
}


