import SwiftUI

struct OptionView: View {
    var title: String
    var subtitle: String
    
    var body: some View {
        HStack {
            Spacer()
            
            VStack  {
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                
                Text(subtitle)
                    .font(.title)
                    .lineLimit(4)
            }
            .padding(15)
            
            Spacer()
            
        }
        .background(Color.white)
        .foregroundColor(.black)
        .cornerRadius(20.0)
        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 0)
        .padding([.top, .horizontal])
        
    }
}

struct SectionView: View {
    @Binding var index: Int
    @Binding var options: [Food]
    @Binding var showSV: Bool
    @Binding var showCV: Bool
    @Binding var conclusion: String
    
    var body: some View {
        VStack {
            QuestionView(text: Data.sections[index].question)
            OptionsView(foods: Data.sections[index].options, index: $index, options: $options,  showSV: $showSV, showCV: $showCV, conclusion: $conclusion)
        }
    }
}

struct OptionsView: View {
    var foods: [Food]
    @Binding var index: Int
    @Binding var options: [Food]
    @Binding var showSV: Bool
    @Binding var showCV: Bool
    @Binding var conclusion: String
    private let types: [String] = ["my breakfast", "my lunch", "my dinner", "my snack", "my special beverage"]
    
    var body: some View {
        VStack {
            ForEach(0..<foods.count, id:\.self) { i in
                OptionView(title: foods[i].name, subtitle: foods[i].description)
                    .onTapGesture {
                        conclusion += ("\n• " + foods[i].name + " for " + types[index])
                        options.append(foods[i])
                        if index == foods.count {
                            showSV = false
                            showCV = true
                        } else {
                            index += 1
                        }
                    }
            }
        }
    }
}

struct QuestionView: View {
    var text: String
    
    var body: some View {
        HStack {
            Spacer()
            
            Text(text)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .foregroundColor(.black)
            
            Spacer()
        }
        .padding()
    }
}

struct IntroductionView: View {
    @State var text: String = "Hello, guys.😇\n\nI will go to one of the biggest cities in Indonesia, that is Surabaya.🌃\n\nI got many recommendations from my friends to try Surabaya food specialties for every meal time.🥦🥬🥒\n\nPlease, help me to choose what food I will try.🥰"
    @Binding var showIV: Bool
    @Binding var showSV: Bool
    
    var body: some View {
        VStack {
            
            TextView(parameter: $text)
            
            Button {
                showIV = false
                showSV = true
            } label : {
                Text("Ok, I'll help")
                    .font(.title2)
                    .padding()
            }
            .background(Color.accentColor)
            .foregroundColor(.white)
            .cornerRadius(15.0)
        }
        
    }
}

struct TextView: View {
    @State var text: String = ""
    @Binding var parameter: String
    
    var body: some View {
        HStack {
            Text(text)
                .foregroundColor(.black)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
                .animation(.spring())
                .padding(30)
        }
        .onAppear(perform: {
            parameter.enumerated().forEach { index, character in
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                    text += String(character)
                }
            }
        })
    }
}

struct ConclusionView: View {
    @Binding var text: String
    
    var body: some View {
        TextView(parameter: $text)
    }
}

public struct ContentView: View {
    @State var showIV: Bool = true
    @State var showSV: Bool = false
    @State var showCV: Bool = false
    @State var index: Int = 0
    @State var options: [Food]
    @State var conclusion: String = "Thank you for helping me choose the foods that I'll eat while I'm in surabaya.😇\nSo, I'll take : "
    
    public init() {
        options = [Food]()
    }
    
    public var body: some View {
        return Group {
            ZStack {
                Color(.white).edgesIgnoringSafeArea(.all)
                
            if showIV {
                IntroductionView(showIV: $showIV, showSV: $showSV)
            } else {
                if showSV {
                    SectionView(index: $index, options: $options, showSV: $showSV, showCV: $showCV, conclusion: $conclusion)
                } else {
                    ConclusionView(text: $conclusion)
                }
            }
            }
            
        }
    }
    
}

